//
//  main.cpp
//  Assigment@
//
//  Created by Yusufjon Tohirov on 04/10/23.
//

#include <iostream>
using namespace std;
#include <cmath>

void problem1(){
    //Problem 1
   // Write a program which asks for a number input from the keyboard . Add 40 to the number and then divide it by 5. Now, subtract 6 from the number and then multiply the resultant value by 10. Display the result.
    cout<<"Problem 1"<<endl;
    int num1;
    cout<<"Enter number: ";
    cin>>num1;
    int result = (floor((num1 + 40)/5)-6)*10;
    cout<<"Answer is: "<<result<<endl;
    
}
void problem2(){
    //39.37
    //Problem 2
    //Write a program which takes length in meters as input and convert it to inches and display it as output.
    cout<<"Problem 2"<<endl;
    int length;
    cout<<"Enter the lenght: ";
    cin>>length;
    cout<<"Length in inches will be: "<<length * 39.27<<endl;
}
void problem3(){
    //Problem 3
   // Write a program to calculate the GPA. The marks and credit hours should be given by program. Calculate the GPA and print the result to the console.
    cout<<"Problem 3"<<endl;

    string subjectName;
    int numOfCredists = 0;
    double grade;
    double resultGrade = 0;
    int creditsResult = 0;
    int numAllSubjects;
    double GPA;
    int smt=0;
    cout<<"Enter number all subjects ";
    cin>>numAllSubjects;
    
    
    while (smt != numAllSubjects) {
        cout<<"Enter name of subject and number of credits and your grade "<<endl;
        cin>>subjectName  >> numOfCredists >> grade;
        creditsResult += numOfCredists ;
        resultGrade += grade;
        smt++;
    }
    if(smt == numAllSubjects){
        GPA = resultGrade/numOfCredists;
        cout<<"Your GPA is "<< GPA<<endl;
    }
    else{
        cout<<"Invalid code";
    }
}
void problem4(){
    //Problem 4
    //Write a program to ask radius of circle and calculate the area. Formula: Area = pi*r*r where r is radius of circle.
    cout<<"Problem 4"<<endl;

    const int pi = 3.14;
    int radius;
    cout<<"Enter radius: ";
    cin>>radius;
    int area = pi*radius*radius;
    cout<<"Area of circule is: "<<area<<endl;
}
void problem5(){
   // Problem 5
   // Write a program which accepts days as integer and display total number of years, months and days in it. for example : If user input as 856 days the output should be 2 years 4 months 6 days
    cout << "Problem 5" << endl;
    int dayNum;
    cout << "Enter number of days: ";
    cin >> dayNum;
    int years = floor(dayNum/365);
    int month = (dayNum%365)/30;
    int days = (dayNum%365)%30;
    
    cout<<" Days in years: "<<years<<" years "<<month<<" month "<<days<<" days"<<endl;

}



int main() {
    problem1();
    problem2();
    problem3();
    problem4();
    problem5();
    return 0;
}
